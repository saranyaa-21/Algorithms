#!/usr/bin/env python
# coding: utf-8

import time
from collections import defaultdict
class Graph:
    def __init__(self, vertex):
        self.V = vertex
        self.graph = []
 
    def addEdge(self, u, v, w):
        self.graph.append([u, v, w])
 
 
    def findValue(self, parentValue, i):
        if parentValue[i] == i:
            return i
        return self.findValue(parentValue, parentValue[i])
 
    def applyUnion(self, parentValue, rankValue, x, y):
        xrt = self.findValue(parentValue, x)
        yrt = self.findValue(parentValue, y)
        if rankValue[xrt] < rankValue[yrt]:
            parentValue[xrt] = yrt
        elif rankValue[xrt] > rankValue[yrt]:
            parentValue[yrt] = xrt
        else:
            parentValue[yrt] = xrt
            rankValue[xrt] += 1
 
  
    def kruskalMST(self):
        result = []
        i, e, total = 0, 0, 0
        self.graph = sorted(self.graph, key=lambda item: item[2])
        parentValue = []
        rankValue = []
        for node in range(self.V):
            parentValue.append(node)
            rankValue.append(0)
        while e < self.V - 1:
            u, v, w = self.graph[i]
            i = i + 1
            x = self.findValue(parentValue, u)
            y = self.findValue(parentValue, v)
            if x != y:
                e = e + 1
                result.append([u, v, w])
                self.applyUnion(parentValue, rankValue, x, y)
        for u, v, weight in result:
            print("Node1 Node2 - Edge Cost:",chr(u+65),chr(v+65),end =" ")
            print("-",weight)
            total = total + int(weight)
        print("The total cost of minimum spanning tree is ",total,"\n")
for count in range(1,5):
    fp = open("inputFile"+str(count)+".txt")
    for i, line in enumerate(fp):
        if i == 0:
            x = line.split()
            n = int(x[0])
            ne = int(x[1])
            g = Graph(n)
            print("Graph - "+str(count)+" ("+str(n)+" nodes and "+str(ne)+" edges)")
        else:
            if i < ne+1:
                x = line.split()
                g.addEdge(ord(x[0])-65,ord(x[1])-65,int(x[2]))
            else:
                continue
    init_time = time.time()
    g.kruskalMST()
    end_time = time.time()
    print("Time taken to find MST - ",end_time-init_time, " ms\n")
    fp.close()


