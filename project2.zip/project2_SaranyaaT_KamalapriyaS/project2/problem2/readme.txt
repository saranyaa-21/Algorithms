Steps for execution and output:

1. Place the input files and KruskalMinimumSpanningTree.py/KruskalMinimumSpanningTree.ipynb in the same folder.
2. Open .py or .ipynb and execute it(The version of python used to execute the code here was 3.8.5).
3. After running the file successfully, you will find the details of the graph with edges , cost of each edge of minimum spanning tree with the total cost printed at the end of each graph output.
4. This code is designed to execute all 4 input files at a time.

INPUT FORMAT:
1. First line indicates the details of the graph in the format : 
<number of nodes> <number of edges> U  (here U is undirected)
eg: 20 32 U - 20 nodes , 32 edges , Undirected

2. Second line - last line indicates the edges with their weight/cost with edges denoted by capital letter alphabets and weights as integers in the format:
<node 1(A,B,C,..,Z)> <node 2(A,B,C,..,Z)> <weight/cost of edge>
eg: A B 2 - A - edge 1, B - edge 2, 2 - weight/cost of AB

Note : To alter inputs, please follow the given format and replace in any of the given files or rename your file as inputFile1/inputFile2/inputFile3/inputFile4 and check the corresponding output.