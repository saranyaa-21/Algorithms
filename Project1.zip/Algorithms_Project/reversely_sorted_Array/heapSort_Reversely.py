import timeit
import matplotlib.pyplot as plt
import numpy as np
from array import *

executionTimeCollection_reverselysortedArray=[]
#sizesToTest=list(range(1000,7000,1000))
sizes=[4000,5000,6000,10000,50000,60000,70000,100000,200000,300000]
print("######################################################################################################")
print("Reversely Sorted Array - Random values: 1 to 8000, Total rounds of execution: 10")
print("######################################################################################################")
#10 rounds of execution for different array sizes
for i in range(1,11):
    print("Round of Execution:", end =" ")
    print(i)

    for i in sizes:
        reverselySortedArray = """
import numpy as np
def heapify(arr, size, value):
	largest = value 
	left = 2 * value + 1	 
	right = 2 * value + 2	 

	if left < size and arr[largest] < arr[left]:
		largest = left
	
	if right < size and arr[largest] < arr[right]:
		largest = right
	
	if largest != value:
		arr[value], arr[largest] = arr[largest], arr[value] 	
		heapify(arr, size, largest)

def heapSort(array):
	size = len(array)
	for item in range(size//2 - 1, -1, -1):
		heapify(array, size, item)

	for item in range(size-1, 0, -1):
		array[item], array[0] = array[0], array[item] 
		heapify(array, item, 0)

array= np.random.randint(1,8000,%d)
array_reversed = np.sort(array)[::-1]
print("size is ",len(array))
print("Input Array")
print(array_reversed)
heapSort(array_reversed)
print("Output Array")
print(array_reversed)
"""%(i)
        execution_time_reverselySortedArray = timeit.timeit(reverselySortedArray, number=1)
        executionTimeCollection_reverselysortedArray.append(execution_time_reverselySortedArray)
    print("#############################################################")

def split(executionTimeCollection_reverselysortedArray, size):
     arrs = []
     while len(executionTimeCollection_reverselysortedArray) > size:
         pice = executionTimeCollection_reverselysortedArray[:size]
         arrs.append(pice)
         executionTimeCollection_reverselysortedArray = executionTimeCollection_reverselysortedArray[size:]
     arrs.append(executionTimeCollection_reverselysortedArray)
     return arrs

#For Six different input values, storing the execution time in separate list 
executionTimeCollection_reverselysortedArray1=split(executionTimeCollection_reverselysortedArray, 10)

print()
print("Overall Details for Execution Time - 10 rounds. Each array is for each round")
print()
print("Array values are execution time for different array sizes. Array Sizes Used : 4000,5000,6000,10000,50000,60000,70000,100000,200000,300000 ")
print()
print(executionTimeCollection_reverselysortedArray1)

#Calculating the average execution time of different input data size
AvgOfelement1 = (sum(item[0] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement2 = (sum(item[1] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement3 = (sum(item[2] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement4 = (sum(item[3] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement5 = (sum(item[4] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement6 = (sum(item[5] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement7 = (sum(item[6] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement8 = (sum(item[7] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement9 = (sum(item[8] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement10 = (sum(item[9] for item in executionTimeCollection_reverselysortedArray1)/10)

averageValueArray=[]
averageValueArray.append(AvgOfelement1)
averageValueArray.append(AvgOfelement2)
averageValueArray.append(AvgOfelement3)
averageValueArray.append(AvgOfelement4)
averageValueArray.append(AvgOfelement5)
averageValueArray.append(AvgOfelement6)
averageValueArray.append(AvgOfelement7)
averageValueArray.append(AvgOfelement8)
averageValueArray.append(AvgOfelement9)
averageValueArray.append(AvgOfelement10)

print()
print("#############################################################")
print("Average of Execution Time for 10 rounds, for each of the used array sizes ")
print()
print(averageValueArray)

del executionTimeCollection_reverselysortedArray
del executionTimeCollection_reverselysortedArray1

dict={}

for size,time in zip(sizes,averageValueArray):
    dict[size] = time

convertDictionaryToListOfTuples = sorted(dict.items()) # sorted by key, return a list of tuples. Tuples contain size and timeofexecution as value pairs

x, y = zip(*convertDictionaryToListOfTuples) # unpack the list of tuples into two tuples

#X-axis label
plt.xlabel('Input Size') 
#Y-axis label
plt.ylabel('Execution Time in seconds')
#Graph title  
plt.title('Performance Metrics For Reversely Sorted Array - Heap Sort') 
plt.plot(x, y)
plt.show()