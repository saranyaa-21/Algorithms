import timeit
import matplotlib.pyplot as plt
import numpy as np
from array import *

executionTimeCollection_reverselysortedArray=[]
#sizesToTest=list(range(10000,70000,10000))
sizes=[4000,5000,6000,10000,50000,60000,70000,100000,200000,300000]

print("######################################################################################################")
print("Reversely Sorted Array - Random values: 1 to 80000, Total rounds of execution: 10")
print("######################################################################################################")
#10 rounds of execution for different array sizes
for i in range(1,11):
    print("Round of Execution:", end =" ")
    print(i)
    for i in sizes:
        reverselysortedArray = """
import numpy as np

def merge_sort(array, left, right):
    if left >= right:
        return

    middle = (left + right)//2
    merge_sort(array, left, middle)
    merge_sort(array, middle + 1, right)
    merge(array, left, right, middle)

def merge(array, left, right, middle):
    left_portion = array[left:middle + 1]
    right_portion = array[middle+1:right+1]

    left_portion_index = 0
    right_portion_index = 0
    sorted_index = left

    while left_portion_index < len(left_portion) and right_portion_index < len(right_portion):

        if left_portion[left_portion_index] <= right_portion[right_portion_index]:
            array[sorted_index] = left_portion[left_portion_index]
            left_portion_index = left_portion_index + 1

        else:
            array[sorted_index] = right_portion[right_portion_index]
            right_portion_index = right_portion_index + 1

        sorted_index = sorted_index + 1

    while left_portion_index < len(left_portion):
        array[sorted_index] = left_portion[left_portion_index]
        left_portion_index = left_portion_index + 1
        sorted_index = sorted_index + 1

    while right_portion_index < len(right_portion):
        array[sorted_index] = right_portion[right_portion_index]
        right_portion_index = right_portion_index + 1
        sorted_index = sorted_index + 1

array= np.random.randint(1,80000,%d)
array = np.sort(array)[::-1]
merge_sort(array, 0, len(array) -1)
"""%(i)
        execution_time_reverselysortedArray = timeit.timeit(reverselysortedArray, number=1)
        executionTimeCollection_reverselysortedArray.append(execution_time_reverselysortedArray)
    print("#############################################################")
#arr=np.array(executionTimeCollection_sortedArray)
#num_list = arr.tolist() # list 

def split(executionTimeCollection_reverselysortedArray, size):
     arrs = []
     while len(executionTimeCollection_reverselysortedArray) > size:
         pice = executionTimeCollection_reverselysortedArray[:size]
         arrs.append(pice)
         executionTimeCollection_reverselysortedArray = executionTimeCollection_reverselysortedArray[size:]
     arrs.append(executionTimeCollection_reverselysortedArray)
     return arrs

#For Six different input values, storing the execution time in separate list 
executionTimeCollection_reverselysortedArray1=split(executionTimeCollection_reverselysortedArray, 10)

print()
print("Overall Details for Execution Time - 10 rounds. Each array is for each round. ")
print()
print("Array values are execution time for different array sizes. Size: 4000,5000,6000,10000,50000,60000,70000,100000,200000,300000 ")
print()
print(executionTimeCollection_reverselysortedArray1)

#Calculating the average execution time of different input data size
AvgOfelement1 = (sum(item[0] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement2 = (sum(item[1] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement3 = (sum(item[2] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement4 = (sum(item[3] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement5 = (sum(item[4] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement6 = (sum(item[5] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement7 = (sum(item[6] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement8 = (sum(item[7] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement9 = (sum(item[8] for item in executionTimeCollection_reverselysortedArray1)/10)
AvgOfelement10 = (sum(item[9] for item in executionTimeCollection_reverselysortedArray1)/10)

averageValueArray=[]
averageValueArray.append(AvgOfelement1)
averageValueArray.append(AvgOfelement2)
averageValueArray.append(AvgOfelement3)
averageValueArray.append(AvgOfelement4)
averageValueArray.append(AvgOfelement5)
averageValueArray.append(AvgOfelement6)
averageValueArray.append(AvgOfelement7)
averageValueArray.append(AvgOfelement8)
averageValueArray.append(AvgOfelement9)
averageValueArray.append(AvgOfelement10)


print()
print("#############################################################")
print("Average of Execution Time for 10 rounds, for each of the used array sizes ")
print()
print(averageValueArray)

del executionTimeCollection_reverselysortedArray
del executionTimeCollection_reverselysortedArray1

dict={}

for size,time in zip(sizes,averageValueArray):
    dict[size] = time

convertDictionaryToListOfTuples = sorted(dict.items()) # sorted by key, return a list of tuples. Tuples contain size and timeofexecution as value pairs

x, y = zip(*convertDictionaryToListOfTuples) # unpack the list of tuples into two tuples

#X-axis label
plt.xlabel('Input Size') 
#Y-axis label
plt.ylabel('Execution Time in seconds')
#Graph title  
plt.title('Performance Metrics For Reversely Sorted Array - Merge Sort') 
plt.plot(x, y)
plt.show()