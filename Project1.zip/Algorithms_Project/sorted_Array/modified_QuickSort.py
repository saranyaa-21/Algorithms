import timeit
import matplotlib.pyplot as plt
import numpy as np
from array import *
import random
import time
#import pandas as pd
#from pandas import Series, DataFrame
print("############################################################################################")
print("Sorted Array - Random values: 1 to 80000,Total rounds of execution: 10")
print("############################################################################################")
sizes=[4000,5000,6000,10000,50000,60000,70000,100000,200000,300000]
executionTimeCollection_sortedArray=[]

for i in range(1,11):
    print("Round of Execution:", end =" ")
    print(i)
    
    for i in sizes:
        sortedArray = """
limit = 10
def quicksort(array, first, last):
    if first<last:
        size = last - first + 1
        if(size <= limit):
            print("Executing insertion Sort")
            insertion_sort(array, first, last)
        else:
            mid = partition(array, first, last)
            quicksort(array, first, mid-1)
            quicksort(array, mid + 1, last)

def partition(array, first, last):
    pivot = array[last]
    i = first-1
    for j in range(first,last):
        if array[j] < pivot:
            i += 1
            temp = array[i]
            array[i] = array[j]
            array[j] = temp

    tempo = array[i+1]
    array[i+1] = array[last]
    array[last] = tempo

    return i+1

def insertion_sort(array, first, last):
    for item in range(first, last+1):
        key = array[item]
        y = item-1
        while y > -1 and array[y]> key:
            array[y+1] = array[y]
            y = y-1
        array[y+1] = key

if __name__ == '__main__':
    start = time.time()
    array = random.randint(range(100000),%d)
    array.sort()
    quicksort(array, 0, len(numList) - 1)
"""%(i)
        execution_time_sortedArray = timeit.timeit(sortedArray)
        executionTimeCollection_sortedArray.append(execution_time_sortedArray)
print("#############################################################")      


def split(executionTimeCollection_sortedArray, size):
     arrs = []
     while len(executionTimeCollection_sortedArray) > size:
         pice = executionTimeCollection_sortedArray[:size]
         arrs.append(pice)
         executionTimeCollection_sortedArray = executionTimeCollection_sortedArray[size:]
     arrs.append(executionTimeCollection_sortedArray)
     return arrs

#For Six different input values, storing the execution time in separate list 
executionTimeCollection_sortedArray1=split(executionTimeCollection_sortedArray, 10)
print()
print("Overall Details for Execution Time - 10 rounds. Each array is for each round")
print()
print("Array values are execution time for different array sizes. Array Sizes Used : 4000,5000,6000,10000,50000,60000,70000,100000,200000,300000")
print()
print(executionTimeCollection_sortedArray1)

#Calculating the average execution time of different input data size
AvgOfelement1 = (sum(item[0] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement2 = (sum(item[1] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement3 = (sum(item[2] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement4 = (sum(item[3] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement5 = (sum(item[4] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement6 = (sum(item[5] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement7 = (sum(item[6] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement8 = (sum(item[7] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement9 = (sum(item[8] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement10 = (sum(item[9] for item in executionTimeCollection_sortedArray1)/10)

averageValueArray=[]
averageValueArray.append(AvgOfelement1)
averageValueArray.append(AvgOfelement2)
averageValueArray.append(AvgOfelement3)
averageValueArray.append(AvgOfelement4)
averageValueArray.append(AvgOfelement5)
averageValueArray.append(AvgOfelement6)
averageValueArray.append(AvgOfelement7)
averageValueArray.append(AvgOfelement8)
averageValueArray.append(AvgOfelement9)
averageValueArray.append(AvgOfelement10)


print()
print("#############################################################")
print("Average of Execution Time for 10 rounds, for each of the used array sizes ")
print()
print(averageValueArray)

del executionTimeCollection_sortedArray
del executionTimeCollection_sortedArray1


dict={}

for size,time in zip(sizes,averageValueArray):
    dict[size] = time

convertDictionaryToListOfTuples = sorted(dict.items()) # sorted by key, return a list of tuples. Tuples contain size and timeofexecution as value pairs

x, y = zip(*convertDictionaryToListOfTuples) # unpack the list of tuples into two tuples


#X-axis label
plt.xlabel('Input Size') 
#Y-axis label
plt.ylabel('Execution Time in seconds')
#Graph title  
plt.title('Performance Metrics For Sorted Array') 
plt.plot(x, y)
plt.show()
