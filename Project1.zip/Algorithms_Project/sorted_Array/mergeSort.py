import timeit
import matplotlib.pyplot as plt
import numpy as np
from array import *

executionTimeCollection_sortedArray=[]
#sizesToTest=list(range(10000,70000,10000))
print("########################################################################")
print("Sorted Array - Random values: 1 to 80000. Total rounds of execution: 10")
print("#########################################################################")
#10 rounds of execution for different array sizes
sizes=[4000,5000,6000,10000,50000,60000,70000,100000,200000,300000]
for i in range(1,11):
    print("Round of Execution:", end =" ")
    print(i)
    for i in sizes:
        sortedArray = """
import numpy as np
def merge_sort(array, left, right):
    if left >= right:
        return

    middle = (left + right)//2
    merge_sort(array, left, middle)
    merge_sort(array, middle + 1, right)
    merge(array, left, right, middle)

def merge(array, left, right, middle):
    left_portion = array[left:middle + 1]
    right_portion = array[middle+1:right+1]

    left_portion_index = 0
    right_portion_index = 0
    sorted_index = left

    while left_portion_index < len(left_portion) and right_portion_index < len(right_portion):

        if left_portion[left_portion_index] <= right_portion[right_portion_index]:
            array[sorted_index] = left_portion[left_portion_index]
            left_portion_index = left_portion_index + 1

        else:
            array[sorted_index] = right_portion[right_portion_index]
            right_portion_index = right_portion_index + 1

        sorted_index = sorted_index + 1

    while left_portion_index < len(left_portion):
        array[sorted_index] = left_portion[left_portion_index]
        left_portion_index = left_portion_index + 1
        sorted_index = sorted_index + 1

    while right_portion_index < len(right_portion):
        array[sorted_index] = right_portion[right_portion_index]
        right_portion_index = right_portion_index + 1
        sorted_index = sorted_index + 1

array= np.random.randint(1,80000,%d)
array.sort()
print("Array size ",len(array))
print("Input")
print(array)
merge_sort(array, 0, len(array) -1)
print("Output")
print(array)
"""%(i)
        execution_time_sortedArray = timeit.timeit(sortedArray, number=1)
        executionTimeCollection_sortedArray.append(execution_time_sortedArray)
    print("#############################################################")

def split(executionTimeCollection_sortedArray, size):
     arrs = []
     while len(executionTimeCollection_sortedArray) > size:
         pice = executionTimeCollection_sortedArray[:size]
         arrs.append(pice)
         executionTimeCollection_sortedArray = executionTimeCollection_sortedArray[size:]
     arrs.append(executionTimeCollection_sortedArray)
     return arrs

#For Six different input values, storing the execution time in separate list 
executionTimeCollection_sortedArray1=split(executionTimeCollection_sortedArray, 10)

print()
print("Overall Details for Execution Time - 10 rounds. Each array is for each round")
print()
print("Array values are execution time for different array sizes. Array Sizes Used : 4000,5000,6000,10000,50000,60000,70000,100000,200000,300000")
print()
print(executionTimeCollection_sortedArray1)

#Calculating the average execution time of different input data size
AvgOfInputSize10000 = (sum(item[0] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize20000 = (sum(item[1] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize30000 = (sum(item[2] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize40000 = (sum(item[3] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize50000 = (sum(item[4] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize60000 = (sum(item[5] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize70000 = (sum(item[6] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize80000 = (sum(item[7] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize90000 = (sum(item[8] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize100000 = (sum(item[9] for item in executionTimeCollection_sortedArray1)/10)

averageValueArray=[]
averageValueArray.append(AvgOfInputSize10000)
averageValueArray.append(AvgOfInputSize20000)
averageValueArray.append(AvgOfInputSize30000)
averageValueArray.append(AvgOfInputSize40000)
averageValueArray.append(AvgOfInputSize50000)
averageValueArray.append(AvgOfInputSize60000)
averageValueArray.append(AvgOfInputSize70000)
averageValueArray.append(AvgOfInputSize80000)
averageValueArray.append(AvgOfInputSize90000)
averageValueArray.append(AvgOfInputSize100000)

print()
print("#############################################################")
print("Average of Execution Time for 10 rounds, for each of the used array sizes ")
print()
print(averageValueArray)

del executionTimeCollection_sortedArray
del executionTimeCollection_sortedArray1

dict={}

for size,time in zip(sizes,averageValueArray):
    dict[size] = time

convertDictionaryToListOfTuples = sorted(dict.items()) # sorted by key, return a list of tuples. Tuples contain size and timeofexecution as value pairs

x, y = zip(*convertDictionaryToListOfTuples) # unpack the list of tuples into two tuples

#X-axis label
plt.xlabel('Input Size') 
#Y-axis label
plt.ylabel('Execution Time in seconds')
#Graph title  
plt.title('Performance Metrics For Sorted Array') 
plt.plot(x, y)
plt.show()