import timeit
import matplotlib.pyplot as plt
import numpy as np

executionTimeCollection_sortedArray=[]
#sizesToTest=list(range(10000,70000,10000))
print("############################################################################################")
print("Sorted Array - Random values: 1 to 80000,Total rounds of execution: 10")
print("############################################################################################")
sizes=[4000,5000,6000,10000,50000,60000,70000,100000,200000,300000]
for i in range(1,11):
    print("Round of Execution:", end =" ")
    print(i)
    
    for i in sizes:
        sortedArray = """
import numpy as np
def insertion_sort(array):
    for item in range(1,len(array)):
        value = item 
        while(value!=0 and array[value] < array[value-1]):
            temp=array[value-1]
            array[value-1]=array[value]
            array[value]=temp
            value -= 1  

array= np.random.randint(1,80000,%d)
array.sort()
print("size is ",len(array))
print("Input")
print(array)
insertion_sort(array)
print("Output")
print(array)
"""%(i)
        execution_time_sortedArray = timeit.timeit(sortedArray, number=1)
        executionTimeCollection_sortedArray.append(execution_time_sortedArray)
    print("#############################################################")      

def split(executionTimeCollection_sortedArray, size):
     arrs = []
     while len(executionTimeCollection_sortedArray) > size:
         pice = executionTimeCollection_sortedArray[:size]
         arrs.append(pice)
         executionTimeCollection_sortedArray = executionTimeCollection_sortedArray[size:]
     arrs.append(executionTimeCollection_sortedArray)
     return arrs

#For Six different input values, storing the execution time in separate list 
executionTimeCollection_sortedArray1=split(executionTimeCollection_sortedArray, 10)
print()
print("Overall Details for Execution Time - 10 rounds. Each array is for each round")
print()
print("Array values are execution time for different array sizes. Array Sizes Used : 4000,5000,6000,10000,50000,60000,70000,100000,200000,300000")
print()
print(executionTimeCollection_sortedArray1)

#Calculating the average execution time of different input data size
AvgOfelement1 = (sum(item[0] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement2 = (sum(item[1] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement3 = (sum(item[2] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement4 = (sum(item[3] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement5 = (sum(item[4] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement6 = (sum(item[5] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement7 = (sum(item[6] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement8 = (sum(item[7] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement9 = (sum(item[8] for item in executionTimeCollection_sortedArray1)/10)
AvgOfelement10 = (sum(item[9] for item in executionTimeCollection_sortedArray1)/10)

averageValueArray=[]
averageValueArray.append(AvgOfelement1)
averageValueArray.append(AvgOfelement2)
averageValueArray.append(AvgOfelement3)
averageValueArray.append(AvgOfelement4)
averageValueArray.append(AvgOfelement5)
averageValueArray.append(AvgOfelement6)
averageValueArray.append(AvgOfelement7)
averageValueArray.append(AvgOfelement8)
averageValueArray.append(AvgOfelement9)
averageValueArray.append(AvgOfelement10)


print()
print("#############################################################")
print("Average of Execution Time for 10 rounds, for each of the used array sizes ")
print()
print(averageValueArray)

del executionTimeCollection_sortedArray
del executionTimeCollection_sortedArray1

#x=sizes
#y=averageValueArray
#plt.plot(x, y, color ="green")  
#plt.show()


dict={}

for size,time in zip(sizes,averageValueArray):
    dict[size] = time

convertDictionaryToListOfTuples = sorted(dict.items()) # sorted by key, return a list of tuples. Tuples contain size and timeofexecution as value pairs

x, y = zip(*convertDictionaryToListOfTuples) # unpack the list of tuples into two tuples

#X-axis label
plt.xlabel('Input Size') 
#Y-axis label
plt.ylabel('Execution Time in seconds')
#Graph title  
plt.title('Performance Metrics For Sorted Array') 
plt.plot(x, y)
plt.show()

