import timeit
import matplotlib.pyplot as plt
import numpy as np
from array import *

executionTimeCollection_sortedArray=[]
#sizesToTest=list(range(1000,7000,1000))
sizes=[4000,5000,6000,10000,50000,60000,70000,100000,200000,300000]
print("############################################################################################")
print("Sorted Array - Random values: 1 to 80000. Total rounds of execution: 10")
print("############################################################################################")

for i in range(1,11):
    print("Round of Execution:", end =" ")
    print(i)

    for i in sizes:
        sortedArray = """
import random
import numpy as np
def quicksort(array, first, last):
    if first >= last:
        return

    i, j = first, last
    pivot = array[random.randint(first, last)] #choosing random element as pivot 

    while i <= j:
        while array[i] < pivot:
            i += 1
        while array[j] > pivot:
            j -= 1

        if i <= j:
            array[i], array[j] = array[j], array[i]
            i, j = i + 1, j - 1
    quicksort(array, first, j)
    quicksort(array, i, last)

array= np.random.randint(1,80000,%d)
array.sort()
n=len(array)
print("Array size ",len(array))
print("Input")
print(array)
quicksort(array, 0, n-1)
print("Output")
print(array)
"""%(i)
        execution_time_sortedArray = timeit.timeit(sortedArray, number=1)
        executionTimeCollection_sortedArray.append(execution_time_sortedArray)
    print("#############################################################")      

def split(executionTimeCollection_sortedArray, size):
     arrs = []
     while len(executionTimeCollection_sortedArray) > size:
         pice = executionTimeCollection_sortedArray[:size]
         arrs.append(pice)
         executionTimeCollection_sortedArray = executionTimeCollection_sortedArray[size:]
     arrs.append(executionTimeCollection_sortedArray)
     return arrs

#For Six different input values, storing the execution time in separate list 
executionTimeCollection_sortedArray1=split(executionTimeCollection_sortedArray, 10)
print()
print("Overall Details for Execution Time - 10 rounds. Each array is for each round")
print()
print("Array values are execution time for different array sizes. Array Sizes Used : 4000,5000,6000,10000,50000,60000,70000,100000,200000,300000")
print()
print(executionTimeCollection_sortedArray1)

#Calculating the average execution time of different input data size
AvgOfInputSize10000 = (sum(item[0] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize20000 = (sum(item[1] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize30000 = (sum(item[2] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize40000 = (sum(item[3] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize50000 = (sum(item[4] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize60000 = (sum(item[5] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize70000 = (sum(item[6] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize80000 = (sum(item[7] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize90000 = (sum(item[8] for item in executionTimeCollection_sortedArray1)/10)
AvgOfInputSize100000 = (sum(item[9] for item in executionTimeCollection_sortedArray1)/10)

averageValueArray=[]
averageValueArray.append(AvgOfInputSize10000)
averageValueArray.append(AvgOfInputSize20000)
averageValueArray.append(AvgOfInputSize30000)
averageValueArray.append(AvgOfInputSize40000)
averageValueArray.append(AvgOfInputSize50000)
averageValueArray.append(AvgOfInputSize60000)
averageValueArray.append(AvgOfInputSize70000)
averageValueArray.append(AvgOfInputSize80000)
averageValueArray.append(AvgOfInputSize90000)
averageValueArray.append(AvgOfInputSize100000)

print()
print("#############################################################")
print("Average of Execution Time for 10 rounds, for each of the used array sizes ")
print()
print(averageValueArray)

del executionTimeCollection_sortedArray
del executionTimeCollection_sortedArray1

dict={}

for size,time in zip(sizes,averageValueArray):
    dict[size] = time

convertDictionaryToListOfTuples = sorted(dict.items()) # sorted by key, return a list of tuples. Tuples contain size and timeofexecution as value pairs

x, y = zip(*convertDictionaryToListOfTuples) # unpack the list of tuples into two tuples

#X-axis label
plt.xlabel('Input Size') 
#Y-axis label
plt.ylabel('Execution Time in seconds')
#Graph title  
plt.title('Performance Metrics For Sorted Array') 
plt.plot(x, y)
plt.show()